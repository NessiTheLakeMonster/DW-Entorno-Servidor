class Persona {

    constructor(dni, nombre, tfno) {
        this.dni = dni;
        this.nombre = nombre;
        this.tfno = tfno;
    }


}

module.exports = Persona;