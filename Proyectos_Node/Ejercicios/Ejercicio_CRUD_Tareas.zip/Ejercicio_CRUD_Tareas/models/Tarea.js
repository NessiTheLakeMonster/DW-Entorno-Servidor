
class Tarea {

    constructor(descripcion, duracion, dificultad, terminada) {
        this.descripcion = descripcion;
        this.duracion = duracion;
        this.dificultad = dificultad;
        this.terminada = terminada;
    }
}